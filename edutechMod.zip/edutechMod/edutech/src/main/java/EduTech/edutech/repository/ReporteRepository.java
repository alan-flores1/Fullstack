package EduTech.edutech.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import EduTech.edutech.model.Reporte;

import java.util.List;

@Repository

public class ReporteRepository extends JpaRepository<Reporte, Long> {
    List<Usuario> findByfechareporte(Date fechareporte);
}
