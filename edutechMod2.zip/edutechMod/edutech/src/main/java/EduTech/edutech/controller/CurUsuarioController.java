package EduTech.edutech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import EduTech.edutech.model.CursoUsuario;
import EduTech.edutech.service.CurUsuarioService;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.List;


@RestController
@RequestMapping("/api/v1/cursos_usuarios")
public class CurUsuarioController {

    
    @Autowired
    private CurUsuarioService cursoUsuarioService;

    @GetMapping
    public ResponseEntity<List<CursoUsuario>> listar() {
        List<CursoUsuario> cursosUsuarios = cursoUsuarioService.findAll();

        if (cursosUsuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(cursosUsuarios);
    }

    @PostMapping
    public ResponseEntity<CursoUsuario> guardar(@RequestBody CursoUsuario curUsuario) {
        CursoUsuario productoNuevo = cursoUsuarioService.save(curUsuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(productoNuevo);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CursoUsuario> buscar(@PathVariable Integer idcurso) {
        try{
            CursoUsuario clase = cursoUsuarioService.findById(idcurso);
            return ResponseEntity.ok(clase);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
        
    }

    @PutMapping("/{id}")
    public ResponseEntity<CursoUsuario> actualizar(@PathVariable Integer idcurso, @RequestBody CursoUsuario cursoUsuar) {
        try {
            
            CursoUsuario c1 = cursoUsuarioService.findById(idcurso);
            c1.setIdCursoUsuario(idcurso);;
      
            cursoUsuarioService.save(c1);
            return ResponseEntity.ok(c1);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long idcursoUsuario) {
        try {
            cursoUsuarioService.delete(idcursoUsuario);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


}
